import math
class QuadraticEquation:
    def __init__(self, a, b, c):
        pass

    def getA(self):
        pass

    def getB(self):
        pass

    def getC(self):
        pass

    def discriminant(self):
        pass

    def root1(self):
        pass
        
    def root2(self):
        pass
        
    def __str__(self):
        pass
     
