############################################################
# Name: 
# CS515 Lab 1
#  
############################################################

from math import factorial
from functools import reduce

def inverse(x):
    pass

def e(n):
    pass


